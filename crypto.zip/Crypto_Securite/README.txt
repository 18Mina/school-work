Voici les programmes que j'ai utilise lors d'un TP note en cryptographie/securite.

- le programme exponen.py ne marche que si n et p sont premiers (une des conditions d'application du RSA, methode de chiffrement/dechiffrement)

- les programmes vernam4.py et vernam_clepredefinie permettent de chiffrer et dechiffrer un message a l'aide de la methode vernam. dans un cas avec une cle predefinie (011). dans un autre, avec une cle definie par l'utilisateur.

- le programme euclide.py effectue l'algorithme d'euclide etendu avec deux valeurs que l'utilisateur entre.

- le programme decompo.py n'est destine qu'a une seule utilisation par execution, bien que la boucle soit infinie. je n'ai pas gere cela car ce programme n'allait etre utilise que par moi-meme. il faut donc presser les touches Ctrl+C pour quitter le programme et l'executer a nouveau pour pouvoir effectuer la decomposition et l'indicateur d'Euler d'un deuxieme chiffre. (autrement, la valeur de phi calcule la deuxieme fois s'ajoutera au phi precedemment trouve, et on obtient donc une valeur fausse)