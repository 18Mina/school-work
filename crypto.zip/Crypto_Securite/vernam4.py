# -*- coding: utf-8 -*-

def xor(cle, lettre):
	return bool(cle) + bool(lettre) == True

msg_base = []
cle = []
msg_chiffre = []

K = []
a = iter(K)
b = iter (cle)

while 1:
	msg_entre = raw_input("Veuillez entrer le message (binaire) que vous souhaitez chiffrer : ")

	cle_choisie = raw_input("Veuillez saisir la clé (binaire) que vous souhaitez utiliser afin de chiffrer votre message : ")

	if (msg_entre != "" and cle_choisie != ""):	
		msg_base = map(int,str(msg_entre))
		cle = map(int,str(cle_choisie))
		print "Le message à chiffrer : ", msg_base
		print "La clé à utiliser : ", cle
		validation = raw_input("Etes vous sûr de votre choix ? o pour oui, n pour non : ")
		if (validation == 'o'):
			for i in range (len(msg_base)):
				if (next(b,None) == None):
					K.append(cle[i%len(cle)])
				else:
					K.append(cle[i])		
			break

		elif msg_base != "" or validation != 'o':
			for j in msg_base:
				msg_base.remove(j)
			print "Veuillez recommencer"
	else:
		print "Veuillez recommencer"

for d in range (len(msg_base)):	
	resultat = xor(K[d], msg_base[d])	
	
	if (resultat == True):
		msg_chiffre.append(1)
		
				
	if (resultat == False):
		msg_chiffre.append(0)

msg_base[:] = []

print "              #####Fin du cryptage du message######"
print "              #####Message : ", msg_chiffre,"######"

choix = raw_input("Souhaitez-vous décryptez le message ? Y/N ")

if (choix == 'Y'):
	for i in range (len(msg_chiffre)):
		resultat = xor(K[i], msg_chiffre[i])	
	
		if (resultat == True):
			msg_base.append(1)
				
				
		if (resultat == False):
			msg_base.append(0)

	msg_chiffre[:] = []
			
	print "              #####Fin du décryptage du message######"
	print "              #####Message : ", msg_base,"########"

elif (choix == 'N'):
	print "Bye then"

