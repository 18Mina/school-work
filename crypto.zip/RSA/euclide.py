# -*- coding: utf-8 -*-

from __future__ import print_function # pour le end


def euclide(a,b):

	
	if (a%b == 1):
		facteur1 = 1
		facteur2 = -(a/b)

	else:
		pre_facteur1,pre_facteur2 = euclide(b, a%b)
		facteur1 = pre_facteur2		
		facteur2 = pre_facteur1- pre_facteur2 * (a / b)
		
	return facteur1, facteur2


def inverseMod(a,b):
	if a > b:
		noCare, inverse = euclide(a,b)
	else:
		noCare, inverse = euclide(b,a)
	return inverse

a = input("Veuillez entrer un chiffre : ")
b = input("Veuillez entrer un deuxième chiffre : ")

print ("Les facteurs de Bezoult (respectivement du premier et du deuxième chiffre entré) sont : ", euclide(a,b), end = '\n')

print ("l'inverse modulaire (à savoir que le modulo est le plus grand chiffre))", inverseMod(a,b))


#ne pas oublier que l'inverse modulaire peut être modifié car en modulo (on prendra le plus petit supérieur à 0 mais le programme lui donne le plus petit)



