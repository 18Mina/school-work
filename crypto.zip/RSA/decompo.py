# -*- coding: utf-8 -*-

from __future__ import print_function # pour le end


# RSA = M (message en clair) premier avec N (= np)
# e entier naturel tel que PGCD(e, phi(N)) = 1

# M' (message chiffré) = reste de M^e modulo N.(via exponentiation modulaire)

# pour déchiffrer : on détermine d = inverse de e modulo (phi(n))
# M est le reste de M'^d modulo N

phi = 1 # 1 est premier avec tous les nombres
decomp = []
div = 2

while 1:

	nombre_base = input("Veuillez entrer le nombre dont vous voulez la décomposition : ")
	
	nombre = nombre_base
	
	if nombre !=0:
	

		while nombre >1: 
			while (nombre%div == 0):
				decomp.append(div)
				nombre = nombre/div
			div = div + 1

		count = {}.fromkeys(set(decomp),0)

		for i in decomp:
			count[i]+=1
		print (count)


		choix = raw_input("Voulez-vous phi ? ")

		if choix == 'o':
			if count == {nombre_base:1}:
				phi = nombre_base-1
			else:
				for premier, puissance in count.items():
					phi *= premier**puissance - premier**(puissance-1)
			print("phi = ", phi)
			
		else:
			break
	else:
		print ("erreur")
		break
