# -*- coding: utf-8 -*-

from __future__ import print_function # pour le end

phi = 1 # 1 est premier avec tous les nombres
decomp = []
div = 2

while 1:

	nombre_base = input("Veuillez entrer le nombre dont vous voulez la décomposition : ")
	
	nombre = nombre_base
	
	if nombre !=0:
	

		while nombre >1: 
			while (nombre%div == 0):
				decomp.append(div)
				nombre = nombre/div
			div = div + 1

		count = {}.fromkeys(set(decomp),0)

		for i in decomp:
			count[i]+=1
		print (count)


		choix = raw_input("Voulez-vous phi ? ")

		if choix == 'o':
			if count == {nombre_base:1}:
				phi = nombre_base-1
			else:
				for premier, puissance in count.items():
					phi *= premier**puissance - premier**(puissance-1)
			print("phi = ", phi)
			
			
		else:
			break
	else:
		print ("erreur")
		break
