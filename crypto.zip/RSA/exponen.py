# -*- coding: utf-8 -*-

from __future__ import print_function # pour le end

def resteExpoModulaire(message, puissance, modulo):
	binaire = bin(puissance)[2:]
	binaire = binaire[::-1]

	resteCourant = message
	reste = 1

	for i in xrange(len(binaire)):
		resteCourant %= modulo
		if binaire[i] == '1':
			reste *= resteCourant
			reste %= modulo
		resteCourant *= resteCourant

	return reste


message = input("Veuillez entrer le message à chiffrer : ")
e = input("Veuillez entrer la puissance (e) : ")

n = input("Veuillez entrer n, composante de la clé secrète : ")
p = input("Veuillez entrer p, composante de la clé secrète : ")

grand_N = n * p


print (resteExpoModulaire(message, e, grand_N))
