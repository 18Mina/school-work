# -*- coding: utf-8 -*-

def xor(cle, lettre):
	return bool(cle) + bool(lettre) == True

msg_base = []
msg_chiffre = []

#Dans ce programme, la clé est pré-définie
cle = [0,1,1]
K = []
a = iter(K)
b = iter (cle)

while 1:
	msg_entre = raw_input("Veuillez entrer le message (binaire) que vous souhaitez chiffrer : ")

	if (msg_entre != ""):	
		msg_base = map(int,str(msg_entre))
		print msg_base
		validation = raw_input("Etes vous sûre que le message que vous voulez chiffrer est bien celui - ci ? o pour oui, n pour non : ")
		if (validation == 'o'):
			for i in range (len(msg_base)):
				if (next(b,None) == None):
					K.append(cle[i%3])
				else:
					K.append(cle[i])		
			break

		elif msg_base != "" or validation != 'o':
			for j in msg_base:
				msg_base.remove(j)
			print "Veuillez recommencer"
	elif not msg_base:
		print "Veuillez recommencer"

for d in range (len(msg_base)):	
	resultat = xor(K[d], msg_base[d])	
	
	if (resultat == True):
		msg_chiffre.append(1)
		#msg_base.remove(msg_base[d])
				
	if (resultat == False):
		msg_chiffre.append(0)
		#msg_base.remove(msg_base[d])

msg_base[:] = []

print "              #####Fin du cryptage du message######"
print "              #####Message : ", msg_chiffre,"######"

choix = raw_input("Souhaitez-vous décryptez le message ? Y/N ")

if (choix == 'Y'):
	for i in range (len(msg_chiffre)):
		resultat = xor(K[i], msg_chiffre[i])	
	
		if (resultat == True):
			msg_base.append(1)
				
				
		if (resultat == False):
			msg_base.append(0)

	msg_chiffre[:] = []
			
	print "              #####Fin du décryptage du message######"
	print "              #####Message : ", msg_base,"########"

elif (choix == 'N'):
	print "Bye then"

